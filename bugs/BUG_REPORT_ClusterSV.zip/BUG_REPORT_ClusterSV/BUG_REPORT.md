# Bug Report: ClusterSV crashes on internal geometry invariant (`intra_vs_single_intra_p_value`)

**Component:** ClusterSV (`cancerit/ClusterSV`)
**Severity:** High — deterministic, uncatchable crash that aborts the whole clustering job for an entire sample; no workaround at the pipeline level.
**Type:** Defect in ClusterSV R code (not an input/format error, not a resource limit, not a pipeline-config issue).
**Reporter:** BIC (socci) — Proj_16840_N / Adagio WGS run

---

## 1. TL;DR

ClusterSV aborts with an internal `stop()` that is a self-consistency check on geometry **ClusterSV itself computed**. The BEDPE input is valid and is parsed successfully; the crash happens deep inside the p-value/footprint math, in function `intra_vs_single_intra_p_value()` in `R/clustering_index.R`, at the guard the authors wrote precisely because they knew this code is numerically fragile ("Make sure we don't get nasty float comparison issues"). It fails **identically on all 3 retries**, so it is deterministic, not a transient/parallelism race.

Because the failing check validates ClusterSV's *own* intermediate arrays (`good_regions_start` / `good_regions_end`), the fault is localized to ClusterSV code by construction — no BEDPE content can be "malformed" in a way that makes the user responsible for `good_regions_end < good_regions_start`, since ClusterSV builds those vectors itself from an already-parsed, already-validated input.

---

## 2. Environment (exact versions)

| Item | Value |
|---|---|
| Tool | ClusterSV |
| Upstream repo | https://github.com/cancerit/ClusterSV.git |
| Git commit (in container) | `1d7eeea8f22133d811bed6a4cbbaf1ad2122e2c4` ("Merge pull request #7 from whelena/hg38") |
| Container image | `cmopipeline/clustersv:0.0.1` (Singularity: `/scratch/core001/bic/socci/opt/singularity/cachedir/cmopipeline-clustersv-0.0.1.img`) |
| Image build date | 2026-02-13 |
| R | 3.6.1 |
| foreach / doParallel / iterators | 1.4.4 / 1.0.14 / 1.0.10 |
| gtools / R.utils | 3.8.1 / 2.8.0 |
| Reference: chrom sizes | `/opt/ClusterSV/references/hs37d5.chrom_sizes` (chr `2` = `243199373`) |
| Reference: cen/telo | `/opt/ClusterSV/references/hs37d5_centromere_and_telomere_coords.txt` |

Source-of-truth line numbers below are from the copy inside this image (`/opt/ClusterSV/R/clustering_index.R`) at the commit above. Code snippets are quoted verbatim so the defect is locatable even if upstream line numbers have drifted.

---

## 3. Affected sample and BAM provenance

| Field | Value |
|---|---|
| Tumor sample | `APTL_MDA010_T01_D` |
| Normal sample | `TPLL_00005_N01` |
| Pair tag (Nextflow) | `APTL_MDA010_T01_D__TPLL_00005_N01` |
| Tumor BAM | `/data1/core001/work/bic/socci/Users/ElenitK/BermeoJ/Proj_16840_N/Map/sbam/bam/APTL_MDA010_T01_D/APTL_MDA010_T01_D.smap.bam` |
| Tumor BAI | `…/APTL_MDA010_T01_D/APTL_MDA010_T01_D.smap.bam.bai` |
| Normal BAM | `/data1/core001/work/bic/socci/Users/ElenitK/BermeoJ/Proj_17929_E/Map/sbam/bam/TPLL_00005_N01/TPLL_00005_N01.smap.bam` |
| Normal BAI | `…/TPLL_00005_N01/TPLL_00005_N01.smap.bam.bai` |
| Genome build | GRCh37 / hs37d5 |

The BAMs are not required to reproduce — ClusterSV consumes only the BEDPE. Both the full BEDPE and the exact 10-column file ClusterSV actually read are preserved next to this report (see Section 8).

---

## 4. The failing task (as observed in production)

- Nextflow process: `sv_wf:SomaticRunClusterSV (APTL_MDA010_T01_D__TPLL_00005_N01)`
- Failed **3/3 attempts**, exit status **1** each, ~8 min each. Not a timeout / not OOM (requested 8 GB / 2 h; peak RSS on the successful sibling tasks was ~185 MB).
- Work dirs (each contains identical `.command.err`):
  - attempt 1 `…/run/work/f9/c6871b0f737b0a12c2d2ee2dbac3df/`
  - attempt 2 `…/run/work/6f/c13dfd99e7ece254a8494ab211a0bb/`
  - attempt 3 `…/run/work/f4/a774000501e65ab59b4bcb418ddc4c/`
  - (run root: `/scratch/core001/bic/socci/Adagio/20260718_211759_27169/run/`)

### Exact error (identical on all 3 attempts)

```
Error in { :
  task 135 failed - "Failed after removing out of bounds regions: il=218257543.5; ih=218259345.5; score_cutoff=2.11688888888889e-15; s=2961; chr_size=243199373"
Calls: compute_clusters_and_footprints ... clust_rgs -> get_clust_mat -> %dopar% -> <Anonymous>
Execution halted
```

The crash originates in a `%dopar%` worker, so foreach re-raises it as "task 135 failed"; the underlying `stop()` is ClusterSV's own (Section 6).

---

## 5. Why this is NOT a user / input problem

1. **Five sibling samples in the same run, same command, same references, processed cleanly** (exit 0): `APTL_MDA007_T01_D2`, `APTL_MDA008_T01`, `APTL_MDA009_T01`, `APTL_MDA011_T01`, `APTL_MDA012_T01`. Only `APTL_MDA010_T01_D` crashes.

2. **The only material difference is SV density**, which drives ClusterSV's `score_cutoff` into the floating-point danger zone:

   | Sample | SV rows (BEDPE) | ClusterSV result |
   |---|---|---|
   | APTL_MDA012_T01 | 262 | exit 0 |
   | APTL_MDA011_T01 | 263 | exit 0 |
   | APTL_MDA009_T01 | 270 | exit 0 |
   | APTL_MDA008_T01 | 286 | exit 0 |
   | APTL_MDA007_T01_D2 | 322 | exit 0 |
   | **APTL_MDA010_T01_D** | **659** | **exit 1 (crash)** |

   At 659 SVs the reported `score_cutoff` is `2.11688888888889e-15` — i.e. ClusterSV is solving quadratics with a constant term scaled by ~1e-15, exactly the regime where the code's own rounding/float handling breaks.

3. **The input BEDPE is well-formed** and is parsed successfully — the crash is far downstream of parsing, inside the footprint p-value computation. ClusterSV's own README constraints are met (non-empty, breakpoints at basepair resolution).

4. **The failing statement is an internal invariant check on ClusterSV-computed data**, with an author comment acknowledging the fragility. A user cannot be at fault for a violated invariant on arrays the library builds itself.

---

## 6. Root-cause analysis — exact location and mechanism

### 6.1 Where it dies

File: `R/clustering_index.R`
Function: `intra_vs_single_intra_p_value(il, ih, score_cutoff, s, chr_size)` — defined at **line 249**.
Throwing statement: **line 415**.

```r
    # Make sure we don't get nasty float comparison issues.
    good_regions_start = round(good_regions_start)
    good_regions_end = round(good_regions_end)

    # Remove regions that are out of bounds
    bad_idx = good_regions_start > chr_size | good_regions_end < 1
    good_regions_start = good_regions_start[!bad_idx]
    good_regions_end   = good_regions_end[!bad_idx]
    if (any(good_regions_end < good_regions_start)) {          # <-- line 415 guard
        stop(sprintf("Failed after removing out of bounds regions: il=%s; ih=%s; score_cutoff=%s; s=%s; chr_size=%s", il, ih, score_cutoff, s, chr_size))
    }
```

The function builds `good_regions_start` / `good_regions_end` (candidate intervals of chromosome positions) by solving quadratics via `quadratic_root()`, then asserts every interval satisfies `end >= start`. For this input it does not, and the function aborts.

### 6.2 The exact code path this input takes (verifiable arithmetic)

The `foreach` loop is 1:1 with input SV rows. **`task 135` = input row 135**, which is the deletion `TEMPO_DEL_2_218257543_2_218259345_+-`. Its two breakpoint midpoints are the `il`/`ih` in the crash message:

- `il = (218257543 + 218257544) / 2 = 218257543.5`
- `ih = (218259345 + 218259346) / 2 = 218259345.5`
- `s = 2961`, `chr_size = 243199373` (chr2, hs37d5)

Branch selection at line **268** (`if (il <= ih - s)`):

- `ih - s = 218259345.5 - 2961 = 218256384.5`
- `il = 218257543.5`  → `il <= ih - s` is **FALSE** → execution enters the `else` branch at **line 311** ("This is if high ends meet first").

### 6.3 A concrete defect in that exact branch

Inside the `il > ih - s` branch, case 2 (**lines 327-337**):

```r
        # 2) ih-size < pos <= il. Solution for (il-pos) * (pos+size-ih) - score_cutoff*L^2 = 0
        roots = quadratic_root(-1, ih-s+il, -il*ih + il*s - score_cutoff*L^2)
        if (length(roots) <= 1) {
            good_regions_start = c(good_regions_start, ih-s)
            good_regions_end   = c(good_regions_end,   il)
        }
        else {
            round(roots)                                        # <-- line 334, BUG: result discarded
            good_regions_start = c(good_regions_start, ih-s,   roots[2])
            good_regions_end   = c(good_regions_end,   roots[1], il)
        }
```

`round(roots)` at **line 334** is called **without assigning the result back** to `roots`. In R, `round()` is pure — this line is a no-op and the subsequent code uses the **unrounded** `roots`. The two directly analogous two-root `else` branches in this same function assign correctly — `roots = round(roots)` at **line 291** and **line 382**. Line 334 is the lone exception, i.e. a copy-paste/typo defect. (The other rounding sites at lines 271, 298, 314, 341, 361, 389 round a filtered vector and are a different pattern.)

This branch appends a region as `start = roots[2]`, `end = roots[1]`. That is only valid if `roots` is sorted ascending *and* the intended "good" interval is `[roots[1], roots[2]]` — but it is written as `start=roots[2] … end=roots[1]`, which is inverted unless additional ordering guarantees hold. Combined with `score_cutoff ~ 1e-15` (so the two roots are extremely close and float-noisy) and the skipped rounding, this branch is the most direct candidate for producing an `end < start` interval that trips the line-415 guard.

**Note on confidence:** the line-415 `stop()` proves the fault is internal regardless of which region-building branch is ultimately responsible. The discarded `round(roots)` at ~line 336 is a demonstrable, standalone bug that lies on the exact code path this input executes; we flag it as the prime suspect, but the definitive proof of "ClusterSV bug" does not depend on it — the crashed invariant is on ClusterSV's own computed geometry.

### 6.4 The triggering SVs (context)

Two SVs on chr2 share breakpoint 218257543 and sit ~1.8 kb apart — a tight adjacent DUP/DEL pair:

```
row 134:  2  218254582  218254583  2  218257543  218257544  TEMPO_DUP_2_218254582_2_218257543_-+  .  -  +
row 135:  2  218257543  218257544  2  218259345  218259346  TEMPO_DEL_2_218257543_2_218259345_+-  .  +  -
```

Row 135 is the one processed as `task 135`.

---

## 7. Deterministic reproduction

Inputs are preserved (Section 8) so this does not depend on scratch being retained.

```bash
IMG=/scratch/core001/bic/socci/opt/singularity/cachedir/cmopipeline-clustersv-0.0.1.img
DIR=/data1/core001/work/bic/socci/Users/ElenitK/BermeoJ/Proj_16840_N/BUG_REPORT_ClusterSV

singularity exec "$IMG" Rscript /opt/ClusterSV/R/run_cluster_sv.R \
  -chr      /opt/ClusterSV/references/hs37d5.chrom_sizes \
  -cen_telo /opt/ClusterSV/references/hs37d5_centromere_and_telomere_coords.txt \
  -bedpe    "$DIR/APTL_MDA010_T01_D__TPLL_00005_N01.clustersv_input.bedpe" \
  -out      /tmp/clustersv_repro
```

Expected result: aborts with
`task 135 failed - "Failed after removing out of bounds regions: il=218257543.5; ih=218259345.5; score_cutoff=2.11688888888889e-15; s=2961; chr_size=243199373"`.

This is the exact command the pipeline runs (from `.command.sh`), minus the surrounding shell wrapper. The pipeline did not pass `-n`, so it uses the driver's default thread count; the failure is data-dependent, not thread-count-dependent, and reproduces regardless.

---

## 8. Preserved artifacts (bundled with this report)

Directory: `/data1/core001/work/bic/socci/Users/ElenitK/BermeoJ/Proj_16840_N/BUG_REPORT_ClusterSV/`

| File | Description |
|---|---|
| `APTL_MDA010_T01_D__TPLL_00005_N01.clustersv_input.bedpe` | Exact 10-column, header-stripped BEDPE ClusterSV consumed (659 rows). Minimal reproducer input. |
| `APTL_MDA010_T01_D__TPLL_00005_N01.final.bedpe` | Full upstream BEDPE (with header/annotation columns) for provenance. |
| `BUG_REPORT.md` | This document. |

Original (scratch) work dir for attempt 3, if still present:
`/scratch/core001/bic/socci/Adagio/20260718_211759_27169/run/work/f4/a774000501e65ab59b4bcb418ddc4c/`
(contains `.command.sh`, `.command.err`, `.command.log`, `.exitcode`).

---

## 9. What we need from engineering

The `stop()` at line 415 (and its sibling at "Failed after summing regions") is a hard abort inside a `%dopar%` worker, so it is uncatchable/unrecoverable at the pipeline level for the whole sample. Requested direction (in priority order):

1. Fix the region-construction math in `intra_vs_single_intra_p_value()` so it does not emit `end < start` intervals under tiny `score_cutoff` (~1e-15). The discarded `round(roots)` at line 334 (Section 6.3) is the first thing to check; please also audit the `start=roots[2] … end=roots[1]` ordering in that branch (lines 335-336) and its `il <= ih - s` mirror.
2. If a degenerate/empty interval is legitimately possible, it should be normalized (e.g. clamp to empty / swap) rather than `stop()`, so a single pathological breakpoint pair cannot kill the entire sample's clustering.
3. Confirm expected behavior and provide a patched image; we will re-run the preserved reproducer to verify.

---

## 10. Impact

- ClusterSV clustering/footprint annotation (`*.final.clustered.bedpe`) is **missing for `APTL_MDA010_T01_D`** — the `bash -ue` step exits at the failed `Rscript` before writing outputs.
- In this run the pipeline's `errorStrategy` retried 3x then ignored, so downstream steps for the sample still completed and the overall workflow finished (`succeededCount=6377; ignoredCount=1; abortedCount=0`). But any sample dense enough to hit this bug loses its SV clustering silently, and a stricter error strategy would abort the entire run.
- Reproducibility: expected to recur on any sample with a comparably high SV burden and closely-spaced intra-chromosomal breakpoints.
